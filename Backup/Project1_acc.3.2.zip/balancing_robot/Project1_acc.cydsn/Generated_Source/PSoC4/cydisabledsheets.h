#ifndef INCLUDED_CYDISABLEDSHEETS_H
#define INCLUDED_CYDISABLEDSHEETS_H

#define Communication__DISABLED 1u
#define Digital__DISABLED 1u
#define ADC__DISABLED 1u
#define CapSense__DISABLED 1u
#define DAC__DISABLED 1u
#define LCD__DISABLED 1u
#define System__DISABLED 1u

#endif /* INCLUDED_CYDISABLEDSHEETS_H */
